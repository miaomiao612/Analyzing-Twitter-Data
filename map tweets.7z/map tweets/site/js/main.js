/*
 * @Author: miaomiao612 dddoctorr612@gmail.com
 * @Date: 2022-10-15 22:51:33
 * @LastEditors: miaomiao612 dddoctorr612@gmail.com
 * @LastEditTime: 2022-10-20 00:03:07
 * @FilePath: \school-explorer\site\js\index.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

import tweets from '../data/tweets.json' assert {type: 'json'};

let Map = basemap();


function basemap () {
    let Map = L.map('tweets-map').setView([39.99893891432174, -122.13162463991333], 5);

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(Map);
    return Map;
}




function makeTweetsFeature(tweets,Map)
{
    for(let i=0; i<tweets.length;i++){
        let coordinates = [tweets[i]['place'][0]['place']['bounding_box'][0]['lat'],tweets[i]['place'][0]['place']['bounding_box'][0]['long']];
        console.log(coordinates);
        L.circleMarker(coordinates,{
            color:'black',
            fillColor:'#7F00FF',
            stroke: true,
            weight:3,
            fillOpacity:0.6,
            radius:8
        }).addTo(Map);
    }
}

makeTweetsFeature(tweets,Map);

