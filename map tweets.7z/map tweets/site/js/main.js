/*
 * @Author: miaomiao612 dddoctorr612@gmail.com
 * @Date: 2022-10-15 22:51:33
 * @LastEditors: miaomiao612 dddoctorr612@gmail.com
 * @LastEditTime: 2022-10-20 00:03:07
 * @FilePath: \school-explorer\site\js\index.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

import schools from '../data/tweets.json' assert {type: 'json'};

let schoolMap = basemap();


function basemap () {
    let schoolMap = L.map('school-map').setView([39.99893891432174, -122.13162463991333], 5);

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(schoolMap);
    return schoolMap;
}




function makeSchoolFeature(schools,schoolMap)
{
    for(let i=0; i<schools.length;i++){
        let coordinates = [schools[i]['place'][0]['place']['bounding_box'][0]['lat'],schools[i]['place'][0]['place']['bounding_box'][0]['long']];
        console.log(schools[i]['place']);
        L.circle(coordinates,{
            color:'red',
            fillColor:'#f03',
            redius:1000
        }).addTo(schoolMap);
    }
}

makeSchoolFeature(schools,schoolMap);

